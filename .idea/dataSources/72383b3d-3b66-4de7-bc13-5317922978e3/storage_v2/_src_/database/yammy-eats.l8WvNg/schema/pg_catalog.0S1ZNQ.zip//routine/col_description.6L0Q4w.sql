create function col_description(oid, integer) returns text
    stable
    strict
    parallel safe
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function col_description(oid, integer) is 'get description for table column';

alter function col_description(oid, integer) owner to postgres;

